let { Client } = require('pg');
let client = new Client({
    host: "localhost",
    user: "postgres",
    port: 5433,
    password: "12345",
    database: "examportal"
});
client.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
});
module.exports = client;
