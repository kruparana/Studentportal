// There can be console-based and web-based node.js applications.


// console-based:
console.log("hello javatpoint");
console.log('First example in node.js');

// %s (represent string)

console.log('hello %s', 'world');

// console.error(new Error('Hello! This is a wrong'));



const name = 'abc';  
console.warn(`Don't mess with me ${name}!`);   

